#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;

out vec4 fragColor;

void main() {
    const float PI = 3.14159265359;
    vec4 color = vertexColor * ColorModulator;
    vec4 newcol = color;
    if (color[0] == 0 && color[1] == 0 && color[2] == 0 && color[3] < 0.5)
    {
        newcol = vec4(abs(sin((gl_FragCoord.x + gl_FragCoord.y) * 0.01 + GameTime * 2000)), abs(sin((gl_FragCoord.x + gl_FragCoord.y) * 0.01 + PI / 3 + GameTime * 2000)), abs(sin((gl_FragCoord.x + gl_FragCoord.y) * 0.01 + 2 * PI / 3 + GameTime * 2000)), 1);
    }
    fragColor = apply_fog(newcol, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);

}
