#version 150
//Thanks to shockMicro for the check_alpha function

bool check_alpha(float textureAlpha, float targetAlpha) {
	
	float targetLess = targetAlpha - 0.01;
	float targetMore = targetAlpha + 0.01;
	return (textureAlpha > targetLess && textureAlpha < targetMore);
	
}

vec4 emissive_handler(vec4 color, vec4 shading, float alpha) {
    if (check_alpha(alpha,254)) return color;
	else if (check_alpha(alpha,253)) return color*0.7;
	else return color*shading;
}

