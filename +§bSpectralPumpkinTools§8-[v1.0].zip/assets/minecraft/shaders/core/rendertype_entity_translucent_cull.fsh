#version 150

#moj_import <fog.glsl>
#moj_import <emissive_handler.glsl>

uniform sampler2D Sampler0;

uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;

in float vertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec2 texCoord1;
in vec4 normal;

out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0);
	vec4 shading = vertexColor * ColorModulator;
	
	float alpha = textureLod(Sampler0, texCoord0, 0.0).a * 255.0;
	color = emissive_handler(color, shading, alpha);
	if (alpha < 100) discard;
	
    fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
}
