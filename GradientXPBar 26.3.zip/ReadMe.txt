Resource pack created by MandaLin
https://ko-fi.com/mandalin 
https://www.planetminecraft.com/member/mandalin/

TERMS: 
Intended usage: for single player worlds or multiplayer servers.
*Not to be re-distributed without proper credit & all of these terms met.* 
Only re-distribute if included in a pack with distributor's own content added. 
Do not just share this pack without additional content or modifications.
Not to be re-sold or used for commercial purposes.
Not to be included in any commercial or for-profit packs. 

CREDITS: 
MandaLin: 
https://modrinth.com/user/MandaLinTV
https://www.planetminecraft.com/member/mandalin/
https://www.curseforge.com/members/mandalin/projects


